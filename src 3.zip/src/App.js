import React, { Component } from 'react';
import './App.css';
import HeatMap from './HeatMap';
import Popup from './Popup';
import $ from "jquery"
import * as algorithms from './algorithms';
//import * as d3 from 'd3'
class App extends Component {
  constructor(props) {
  super(props);
  this.state = {
    viewgrouptracker:2,
    unionmade:[],
    arr:[],
    clickedA:[],
    groups:[],
    key:0,
    componentDidUpdatecounter:0,
  matrixdata:{},
  sorted_groups:[],
  myd:{},
  // data starts here
  mydata1:{
    '2005-2010_Graduation_Outcomes_-_School_Level ': 
    ['Student Age',
    'DBN',
    'CORE COURSE (MS CORE and 9-12 ONLY)',
'SERVICE CATEGORY(K-9* ONLY)',
'NUMBER OF STUDENTS / SEATS FILLED',
'NUMBER OF SECTIONS',
'AVERAGE CLASS SIZE',
'SIZE OF SMALLEST CLASS',
'SIZE OF LARGEST CLASS',
'DATA SOURCE',
'Demographic',
'Cohort',
'Still Enrolled - % of cohort',
'Dropped Out - n',
'Dropped Out - % of cohort'],
'2006-2007_School_Progress_Report ': ['DBN',
'DISTRICT',
'PERCENT OF STUDENTS IN BOROUGH / GRADE / PROGRAM / SUBJECT'],
'2010-2011_Class_Size_-_School-level_detail ': ['CSD',
'SCHOOLWIDE PUPIL-TEACHER RATIO'],
'2011_-_2016_Demographic_Snapshot ': ['DBN',
'Student Age',
'Year',
'Total Enrollment',
'Grade PK',
'Grade K',
'Grade',
'Present',
'Released'],
'Local_Law_14_Health_Data_-_HS_School ': ['School DBN',
'Community School District',
'City Council District',
'Student Age',
'SCHOOL CODE',
'NUMBER OF SECTIONS',
'AVERAGE CLASS SIZE',
'SIZE OF SMALLEST CLASS',
'SIZE OF LARGEST CLASS',
'DATA SOURCE',
'GRADE ',
'PROGRAM TYPE',
'CORE SUBJECT (MS CORE and 9-12 ONLY)',
'CORE COURSE (MS CORE and 9-12 ONLY)',
'SERVICE CATEGORY(K-9* ONLY)',
'NUMBER OF STUDENTS / SEATS FILLED',
'NUMBER OF SECTIONS','# of 15-16 June and August graduates',
'# of 15-16 June and August graduates meeting high school health requirements',
'%2']},
mydata2: {'Health_Education_K-12_-_Health_Instructors ': [
      'School Name',
      'School DBN',
      'Community School District',
      'City Council District',
      'DBN',
      'Grade Level',
      'Program Type',
      'Department',
      'Number of Students',
      'Number of Classes',
      '# of students in grades 9-12',
      'School Year',
      '# of teachers assigned to teach health'],
     '2015_-_2016_Career_Technical_Education_Report ': ['School DBN',
      'School Name',
      'Is CTE-designated High School',
      'CTE Program Name',
      'CTE Program Industry Cluster',
      'Number of Industry Partners',
      'NYSED Approval Status',
      'Enrolled Student Grades',
      'CTE enrolled Student Count'],
     'Final_Class_Size_Report_Middle___High_School ': [
      'School Name',
      'Subject',
      'Average Class Size'],
     '2016_-_2017_Health_Education_Report ': ['School DBN',
      'Community School District',
      'City Council District',
      'School Name',
      '# of students in grades 9-12 scheduled for at least one semester of health instruction',
      '# of 16-17 June and August graduates',
      '# of 16-17 June and August graduates meeting high school health requirements'],
     '2017-2018_Monthly_Attendance ': ['School',
      'Month Code',
      'CalMonth',
      'GradeLevel',
      'GradeSort',
      'Roster Count',
      'Absent',
      'Present',
      'Released'],
     'Class_Size_Report_Borough_Middle_And_High_School ': ['Borough',
      'Grade Level',
      'Program Type',
      'Department',
      'Class Size',
      'Number of Students',
      'Number of Classes',
      '% of Students within Grade'],
     'ES_Zones_2016-2017 ': ['INITIALS',
      'BORO',
      'the_geom',
      'SCHOOLDIST',
      'CREAT_DATE',
      'EDIT_DATE',
      'BORO_NUM',
      'Shape_Leng',
      'Shape_Area',
      'REMARKS',
      'DBN',
      'ESID_NO',
      'Label',
      'ZONED_DIST'],
     'Local_Law_14_Health_Data_-_HS_School ': ['School DBN',
      'Community School District',
      'City Council District',
      'School Name',
      '# of students in grades 9-12',
      '# of students in grades 9-12 who have completed at least one semester of health instruction  ',
      '%',
      '# of 15-16 June and August graduates',
      '# of 15-16 June and August graduates meeting high school health requirements',
      '%2']}
  }
 this.view_group=this.view_group.bind(this);
 this.view_group2=this.view_group2.bind(this);
 this.Unionmaker=this.Unionmaker.bind(this);
 this.attribute_click_handler=this.attribute_click_handler.bind(this);
 this.togglePopup=this.togglePopup.bind(this);
 this.linedraw.bind=this.linedraw;
 this.matrixgenerator.bind=this.matrixgenerator;
 this.jsonHandler = this.jsonHandler.bind(this);
};
//----------------------------------------------------Union Maker
Unionmaker(mydata){
  var mySet= new Set();
  for(var key in mydata){
      for(var i=0;i<mydata[key].length;i++){
          mySet.add(mydata[key][i]);
      }
      }
return Array.from(mySet);
}
//-----------------------------------------------------ViewGroup click handler starts here
view_group(){
  this.linedraw()
  this.keyhandler();
  var mySet=new Set();
  for(var i=0;i<this.state.clickedA.length;i++){
    mySet.add(this.state.clickedA[i])
  }
  var index=Array.from(mySet);
  var combinations2=algorithms.combinationgen2(index);
  var groups_to_vis=[];
//----------------------------------------------second grouping starts here
var grouped_datasets=algorithms.dataset_grouper(this.state.matrixdata.datasets,this.state.matrixdata.matrix,combinations2,);
//console.log(grouped_datasets)
//----------------------------------------------second grouping ends here
for(var j=0;j<grouped_datasets.length;j++){
  if(grouped_datasets[j][1].length>0){
  var a=<HeatMap count={j+1} key={String(this.state.key)+j} gdatasets={grouped_datasets[j][1]} combinations={grouped_datasets[j][0]} display='child' mypopup={this.togglePopup} clickedA={this.state.clickedA} clickhandler={this.attribute_click_handler} datasets={this.state.matrixdata} commonA={this.state.unionmade}  />
  groups_to_vis.push({'item':a,'totalatt':grouped_datasets[j][0].length,'total_datasets':grouped_datasets[j][1].length});
  }
  this.setState({groups:groups_to_vis});
}
  //console.log("view group ",groups_to_vis)
}
//-----------------------------------------------------Group According To datasets click handler starts here
view_group2(){
  console.log("viewGroup2");
  //$(".mylines").hide();
  this.linedraw()
  var a=this.state.groups.sort(function (a, b) {
    return b.total_datasets - a.total_datasets;
  });
  this.setState({sorted_groups:a})
}
view_group3=()=>{
  var a=this.state.groups.sort(function (a, b) {
    return b.totalatt - a.totalatt;
  });
  this.setState({sorted_groups:a})
}
//-----------------------------------------------------Key Handler
keyhandler=()=>{
  var a=this.state.key;
  a++;
  this.setState({key:a})
}
//-----------------------------------------------------IndextoAttribute Generator function
index2atrr=(indexArray)=>{
  var result=[];
  for(var i=0;i<indexArray.length;i++){
    //if(typeof(this.state.unionmade[indexArray[i]])!= "undefined"){
      //console.log(this.state.unionmade[indexArray[i]])
      result.push(this.state.unionmade[indexArray[i]]);
    //}
  }
//console.log(algorithms.matrixgen(result,this.state.mydata2))
return result;
}
//-----------------------------------------------------attribute_click_handler starts here
attribute_click_handler(id,index,axis){
//---------------To handle dataset clicks
if(axis=='y'){
  console.log(id)
  this.togglePopup();
}
else{
  var arr=this.state.clickedA;
//---------------To remove attributes from array
  if(this.state.clickedA.includes(index)){
    arr = this.state.clickedA.filter(function(e) { return e !== index })
    this.classRemover(id,'textcolor');
  }
  else{
    this.classAdder(id,'textcolor')
    arr.push(index)
  }
  this.setState({clickedA:arr},()=>{
    // change Here to implement all attributes or selected attributes
    if(this.state.viewgrouptracker==2){
      this.view_group();
    }
    else{
      this.view_group2();
    }
  })
}
  }
//----------------------------------------------------- Class Adder
classAdder = (id,class_name)=>{
var element = document.getElementById(id);
//element.style.fill = 'blue';
element.classList.add(class_name);
}
//----------------------------------------------------- Class Remover
classRemover = (id,class_name)=>{
  var element = document.getElementById(id);
  element.classList.remove(class_name);
  }  
//-----------------------------------------------------ComponentDidmount
componentDidMount(){
  this.matrixgenerator()
}
//----------------------------------------------------- togglePopup
togglePopup(){
  this.setState({
    showPopup: !this.state.showPopup
  });
}
//---------------------------------------------------------------ComponentDidUpdate
componentDidUpdate(prevState,prevProp){
  this.linedraw()
  return false;  
}
//---------------------------------------------------------------Line draw function starts here
linedraw(){
  var selectedonly=true;
  $("."+"mylines").remove();
  //$(".svg0svg01385").remove(); 
var svgs=$(".svgRectContainer"); var IdArray=[]; for(var i=0;i<svgs.length;i++){ IdArray.push(svgs[i].id)}
// ------------------------------------------------------------Outer for loop for lines starts here
  for(var i=0;i<IdArray.length-1;i++){
    console.log(i);
    var s1length=$("#"+IdArray[i]).find( ".cell" ).length; // only useful for else
    var cellcount=0;
    if(selectedonly){
// ------------------------------------------------------------number of lines to draw is determined here
  for(var k=0;k<this.state.clickedA.length;k++){
    var j=this.state.clickedA[k]+s1length-this.state.unionmade.length;
    var s1c1=$("#"+IdArray[i]+" #cell"+j);
    var s2c1=$("#"+IdArray[i+1]+" #cell"+cellcount);
    cellcount++;
    var myline=IdArray[i]+j;
    var x1 = $(s1c1).offset().left + ($(s1c1).width()/2);
    var y1 = $(s1c1).offset().top + ($(s1c1).height());
    var y2 = $(s2c1).offset().top;
    if($("."+myline).length==0){
      $("#mySVG").clone().addClass(myline).addClass("mylines").insertBefore($("#mySVG").css({left:x1-2,top:y1+3,width:1,opacity:.8,height:y2-y1-5,backgroundColor:"rgb(158,154,200)"})); 
    }  
  }    
}
//if ends here
else{
    for(var j=s1length-this.state.unionmade.length;j<s1length;j++){
s1c1=$("#"+IdArray[i]+" #cell"+j);
s2c1=$("#"+IdArray[i+1]+" #cell"+cellcount);
cellcount++;
myline=IdArray[i]+j;
var x1 = $(s1c1).offset().left + ($(s1c1).width()/2);
var y1 = $(s1c1).offset().top + ($(s1c1).height());
var y2 = $(s2c1).offset().top;
if($("."+myline).length==0){
  $("#mySVG").clone().addClass(myline).addClass("mylines").insertBefore($("#mySVG").css({left:x1-2,top:y1+3,width:1,opacity:.5,height:y2-y1-5,backgroundColor:"rgb(158,154,200)"})); 
}  
}  
} 
//else ends here
}
  }
//------------------------------------------------------------- Json Handler starts Here
jsonHandler(){
const self=this;
var url = "http://127.0.0.1:5000/json";
var data = {myrequest: 'data'};
fetch(url, {
  method: 'POST', 
  body: JSON.stringify(data),
  headers:{
    'Content-Type': 'application/json'
  }
}).then(res => res.json())
.then(response => {
  console.log(self.state.mydata2)
  self.setState({mydata2:response})
  console.log(self.state.mydata2)
  self.matrixgenerator()
  return response;
}).catch(error => console.error('Error:', error));
}
matrixgenerator(){
  var unionedA=this.Unionmaker(this.state.mydata2);
  this.setState({unionmade:unionedA})
  var matrixdata=algorithms.matrixgen(unionedA,this.state.mydata2);
  this.setState({matrixdata:matrixdata})
}

//-----------------------------------------------------------------Render function starts here  
render() {
  if(Object.keys(this.state.matrixdata).length>0){
  }
    return (
     <div className="container-fluid">
        <div className="row">
              <div className="col-3">
              <button onClick={this.view_group2} className="btn  btn-outline-secondary">Sort by datasets</button>
              <button onClick={this.view_group3} className="btn  btn-outline-secondary">Sort by attributes</button>
              <button onClick={this.jsonHandler} className="btn  btn-outline-secondary">Process data</button>
              </div>
              <div className="matrix col-9">
              
              {
                  (Object.keys(this.state.matrixdata).length>0)?<HeatMap key={'key1'} gdatasets={[]} display='main' clickhandler={this.attribute_click_handler} datasets={this.state.matrixdata} commonA={this.state.unionmade} />:"NA"
              }
              { 
                this.state.groups.map( (d,i)=> {
                  return d.item
                })  
              }
              </div>
        </div>      
      { // pop up window 
        this.state.showPopup ? 
          <Popup
            text='Close Me'
            closePopup={this.togglePopup.bind(this)}
          />
          : null
      }
      <div id="mySVG">
      </div>
    </div>
    );
  }
}
export default App;

