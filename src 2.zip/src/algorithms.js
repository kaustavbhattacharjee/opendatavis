/*
var datasets_in_dictionary={
    dataset2: ['A','B','C','D','E'],
    dataset3: ['A','B','AA','BB','CC','DD','EE'],
    dataset4: ['A','B','BBB','DDD','C'],
    }
var attributes_from_union=['A','B','C','D','E','AA','BB','CC','DD','EE','BBB','DDD'];
*/
//------------------------------------------------------------------------------------------------------ Matrix generator starts here
export function test(d){
return d;
}
export function matrixgen(attributes_from_union,datasets_in_dictionary){
    //console.log(datasets_in_dictionary)
var datasets=[];
//var size=Object.keys(datasets_in_dictionary).length;
var matrix=new Array(Object.keys(datasets_in_dictionary).length);
var count=0;
for (var combinations_key in datasets_in_dictionary){
    datasets.push(combinations_key);
    matrix[count]=new Array(attributes_from_union.length);
    for(var combination_index=0;combination_index<attributes_from_union.length;combination_index++){
        for(var j=0;j<datasets_in_dictionary[combinations_key].length;j++){
            if(attributes_from_union[combination_index]==datasets_in_dictionary[combinations_key][j]){
           //console.log(matrix[count]);
            matrix[count][combination_index]=1;
        }
        else{
            if(!matrix[count][combination_index]==1){
                matrix[count][combination_index]=0;
            }
        }
    }
}
count++;
}
return {'datasets':datasets,'matrix':matrix}
}
//console.log(matrixgen(attributes_from_union,datasets_in_dictionary)['datasets'])
//console.log(datasets,matrix);
//------------------------------------------------------------------------------------------------------  Combination generator starts here
export function combinationgen(array){
   var combdict=[];
    function fork(i, t) {
        if (i === array.length) {
            result.push(t);
            return;
        }
        fork(i + 1, t.concat([array[i]]));
        fork(i + 1, t);
    }
    var result = [];
    fork(0, []);
    for(var i=0;i<result.length;i++){
        if(result[i].length>0){
            combdict.push({[result[i].length]:result[i]})
        }
    }
    return combdict;
    }
//console.log('Combination Generator has generated : ',combinationgen([0,2])) 
//console.log(combinationgen([4,5,0]))
//------------------------------------------------------------------------------------------------------ Dataset genrator with comobination matrix
export function combination_matched(matrix,datasets,combination){
    var combinations_with_mathced_datasets=[];
    var len=combination.length-1;
    for (var combination_index=len;combination_index>=0;combination_index--){
            for(var combinations_key in combination[combination_index]){
                var count=0;
                for(var combinations_dictionary_iterator=0;combinations_dictionary_iterator<combination[combination_index][combinations_key].length;combinations_dictionary_iterator++){
                    //console.log("----");  
                    count++;
                    for(var fi=0;fi<datasets.length;fi++){
                    if(matrix[fi][combination[combination_index][combinations_key][combinations_dictionary_iterator]]){
                        //console.log(combination[combination_index][combinations_key],datasets[fi],combination[combination_index][combinations_key].length,count);
                        if(count==combination[combination_index][combinations_key].length){
                            combinations_with_mathced_datasets.push({[count]:combination[combination_index][combinations_key],'Dataset':datasets[fi]})
                            //console.log(combination[combination_index][combinations_key],datasets[fi],combination[combination_index][combinations_key].length,count);
                        }
                    }   
                }
            }
        }
    }
return combinations_with_mathced_datasets;      
}
//var combination=combinationgen([0,1,2]);
//var matrixgen=matrixgen(attributes_from_union,datasets_in_dictionary);
//console.log(combination_matched(matrixgen['matrix'],matrixgen['datasets']),combination);
//------------------------------------------------------------------------------------------------------ Dataset grouping_based_on_combination starts here
export function grouping_based_on_combination(combinations,combinationmatched){
    //console.log('Combinations : ',combinations);
    //console.log('Combination matched : ',combinationmatched);
    var len=combinations.length-1;
    var group =0;
    var arr_group=[];
    for (var combination_index=len;combination_index>=0;combination_index--){
        var arr=[];
        for(var combinations_key in combinations[combination_index]){
            for(var combination_mathced_iterator=0;combination_mathced_iterator<combinationmatched.length;combination_mathced_iterator++){
                for(var key_in_combination_mathced in combinationmatched[combination_mathced_iterator]){
                    if(JSON.stringify(combinations[combination_index][combinations_key])== JSON.stringify(combinationmatched[combination_mathced_iterator][key_in_combination_mathced])){
                        arr.push(combinationmatched[combination_mathced_iterator]['Dataset']);
                    }
                }
            }
            arr_group.push({[group]:arr,'dataset':arr,'attributes_index':combinations[combination_index][combinations_key],'occurence':combinations[combination_index][combinations_key].length,'number_of_dataset':arr.length})
            }
            group++;
        }
        //console.log(arr_group)
    return arr_group;
    }
//var mymatrixgen=matrixgen(attributes_from_union,datasets_in_dictionary);
//var combinations=combinationgen([0,1,2]);
//var combinationmatched=combination_matched(mymatrixgen['matrix'],mymatrixgen['datasets'],combinations)
//console.log(datasetgenwithcombination)
//var groupeddatasetsfromcombination=grouping_based_on_combination(combinations,combinationmatched);
//console.log(grouping_based_on_combination(combinations,combinationmatched));
//------------------------------------------------------------------------------------------------------ To design each dataset based on their groups
export function print_datasts_with_groups(grouped_datasets_from_combination){
for(var i=0;i<grouped_datasets_from_combination.length;i++){
    //console.log('Group : ',i);
    for(var j=0;j<grouped_datasets_from_combination[i]['dataset'].length;j++){
        //console.log('group : ',i," dataset: ",grouped_datasets_from_combination[i]['dataset'][j]);
        //console.log('group : ',i," dataset: ",datasets_in_dictionary[grouped_datasets_from_combination[i]['dataset'][j]]);
    }    
    //console.log(grouped_datasets_from_combination[i]['dataset'],' number of combinations matched : ',grouped_datasets_from_combination[i]['occurence'],'number_of_datasets matched',grouped_datasets_from_combination[i]['number_of_dataset']);
}
}
//print_datasts_with_groups(groupeddatasetsfromcombination);

