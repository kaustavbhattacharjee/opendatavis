import React, { Component } from 'react';
import './App.css';
import HeatMap from './HeatMap';
import Popup from './Popup';
import * as algorithms from './algorithms';
//import * as d3 from 'd3'
class App extends Component {
  constructor(props) {
  super(props);
  this.state = {
    viewgrouptracker:1,
    unionmade:[],
    arr:[],
    clickedA:[],
    groups:[],
    key:0,
  matrixdata:{},
  mydata1:{
    '2005-2010_Graduation_Outcomes_-_School_Level.csv': 
    ['Student Age',
    'DBN',
    'CORE COURSE (MS CORE and 9-12 ONLY)',
'SERVICE CATEGORY(K-9* ONLY)',
'NUMBER OF STUDENTS / SEATS FILLED',
'NUMBER OF SECTIONS',
'AVERAGE CLASS SIZE',
'SIZE OF SMALLEST CLASS',
'SIZE OF LARGEST CLASS',
'DATA SOURCE',
'Demographic',
'Cohort',
'Still Enrolled - % of cohort',
'Dropped Out - n',
'Dropped Out - % of cohort'],
'2006-2007_School_Progress_Report.csv': ['DBN',
'DISTRICT',
'PERCENT OF STUDENTS IN BOROUGH / GRADE / PROGRAM / SUBJECT'],
'2010-2011_Class_Size_-_School-level_detail.csv': ['CSD',
'SCHOOLWIDE PUPIL-TEACHER RATIO'],
'2011_-_2016_Demographic_Snapshot.csv': ['DBN',
'Student Age',
'Year',
'Total Enrollment',
'Grade PK',
'Grade K',
'Grade',
'Present',
'Released'],
'Local_Law_14_Health_Data_-_HS_School.csv': ['School DBN',
'Community School District',
'City Council District',
'Student Age',
'SCHOOL CODE',
'NUMBER OF SECTIONS',
'AVERAGE CLASS SIZE',
'SIZE OF SMALLEST CLASS',
'SIZE OF LARGEST CLASS',
'DATA SOURCE',
'GRADE ',
'PROGRAM TYPE',
'CORE SUBJECT (MS CORE and 9-12 ONLY)',
'CORE COURSE (MS CORE and 9-12 ONLY)',
'SERVICE CATEGORY(K-9* ONLY)',
'NUMBER OF STUDENTS / SEATS FILLED',
'NUMBER OF SECTIONS','# of 15-16 June and August graduates',
'# of 15-16 June and August graduates meeting high school health requirements',
'%2']},
mydata2: {'Health_Education_K-12_-_Health_Instructors.csv': [
      'School Name',
      'School DBN',
      'Community School District',
      'City Council District',
      'DBN',
      'Grade Level',
      'Program Type',
      'Department',
      'Number of Students',
      'Number of Classes',
      '# of students in grades 9-12',
      'School Year',
      '# of teachers assigned to teach health'],
     '2015_-_2016_Career_Technical_Education_Report.csv': ['School DBN',
      'School Name',
      'Is CTE-designated High School',
      'CTE Program Name',
      'CTE Program Industry Cluster',
      'Number of Industry Partners',
      'NYSED Approval Status',
      'Enrolled Student Grades',
      'CTE enrolled Student Count'],
     'Final_Class_Size_Report_Middle___High_School.csv': [
      'School Name',
      'Subject',
      'Average Class Size'],
     '2016_-_2017_Health_Education_Report.csv': ['School DBN',
      'Community School District',
      'City Council District',
      'School Name',
      '# of students in grades 9-12 scheduled for at least one semester of health instruction',
      '# of 16-17 June and August graduates',
      '# of 16-17 June and August graduates meeting high school health requirements'],
     '2017-2018_Monthly_Attendance.csv': ['School',
      'Month Code',
      'CalMonth',
      'GradeLevel',
      'GradeSort',
      'Roster Count',
      'Absent',
      'Present',
      'Released'],
     'Class_Size_Report_Borough_Middle_And_High_School.csv': ['Borough',
      'Grade Level',
      'Program Type',
      'Department',
      'Class Size',
      'Number of Students',
      'Number of Classes',
      '% of Students within Grade'],
     'ES_Zones_2016-2017.csv': ['INITIALS',
      'BORO',
      'the_geom',
      'SCHOOLDIST',
      'CREAT_DATE',
      'EDIT_DATE',
      'BORO_NUM',
      'Shape_Leng',
      'Shape_Area',
      'REMARKS',
      'DBN',
      'ESID_NO',
      'Label',
      'ZONED_DIST'],
     'Local_Law_14_Health_Data_-_HS_School.csv': ['School DBN',
      'Community School District',
      'City Council District',
      'School Name',
      '# of students in grades 9-12',
      '# of students in grades 9-12 who have completed at least one semester of health instruction  ',
      '%',
      '# of 15-16 June and August graduates',
      '# of 15-16 June and August graduates meeting high school health requirements',
      '%2']}
  }
 this.view_group=this.view_group.bind(this);
 this.view_group2=this.view_group2.bind(this);
 this.Unionmaker=this.Unionmaker.bind(this);
 this.attribute_click_handler=this.attribute_click_handler.bind(this);
 this.togglePopup=this.togglePopup.bind(this);
};
//----------------------------------------------------Union Maker
Unionmaker(mydata){
  var mySet= new Set();
  for(var key in mydata){
      for(var i=0;i<mydata[key].length;i++){
          mySet.add(mydata[key][i]);
      }
      }
return Array.from(mySet);
}
//-----------------------------------------------------ViewGroup click handler starts here
view_group(){
  this.setState({viewgrouptracker:2})
  this.keyhandler();
  var mySet=new Set();
  for(var i=0;i<this.state.clickedA.length;i++){
    mySet.add(this.state.clickedA[i])
  }
  var index=Array.from(mySet);
  var combinations=algorithms.combinationgen(index);
  var combinationmatched=algorithms.combination_matched(this.state.matrixdata.matrix,this.state.matrixdata.datasets,combinations)
  var groups=algorithms.grouping_based_on_combination(combinations,combinationmatched);
  var groups_to_vis=[];
  for(var j=0;j<groups.length;j++){
    console.log('combinations : ',combinations ,'j is: ',j,combinations[j]);
    var a=<HeatMap key={String(this.state.key)+j} combinations={combinations} gdatasets={groups[j].dataset} display='child' mypopup={this.togglePopup} clickedA={this.state.clickedA} clickhandler={this.attribute_click_handler} datasets={this.state.matrixdata} commonA={this.state.unionmade}  />
    groups_to_vis.push(a);
  }
  this.setState({groups:groups_to_vis});
  console.log("view group ",groups_to_vis)
}
//-----------------------------------------------------ViewGroup2 click handler starts here
view_group2(){
  this.setState({viewgrouptracker:1})
  this.keyhandler();
  var clickedAttr=this.index2atrr(this.state.clickedA);
  var matrixdata = algorithms.matrixgen(clickedAttr,this.state.mydata2)
  var mySet=new Set();
  for(var i=0;i<this.state.clickedA.length;i++){
    mySet.add(this.state.clickedA[i])
  }
  var index=Array.from(mySet);
  var combinations=algorithms.combinationgen(index);
  var combinationmatched=algorithms.combination_matched(this.state.matrixdata.matrix,this.state.matrixdata.datasets,combinations)
  var groups=algorithms.grouping_based_on_combination(combinations,combinationmatched);
  var groups_to_vis=[];
  for(var j=0;j<groups.length;j++){
    //console.log("keys : ",j);
    var a=<HeatMap key={String(this.state.key)+j} combinations={combinations} gdatasets={groups[j].dataset} display='child' clickedA={clickedAttr} clickhandler={this.attribute_click_handler} mypopup={this.togglePopup} datasets={matrixdata} commonA={clickedAttr}  />
    groups_to_vis.push(a);
  }
  this.setState({groups:groups_to_vis});
}
//-----------------------------------------------------Key Handler
keyhandler=()=>{
  var a=this.state.key;
  a++;
  this.setState({key:a})
}
//-----------------------------------------------------IndextoAttribute Generator function
index2atrr=(indexArray)=>{
  var result=[];
  for(var i=0;i<indexArray.length;i++){
    //if(typeof(this.state.unionmade[indexArray[i]])!= "undefined"){
      //console.log(this.state.unionmade[indexArray[i]])
      result.push(this.state.unionmade[indexArray[i]]);
    //}
  }
//console.log(algorithms.matrixgen(result,this.state.mydata2))
return result;
}
//-----------------------------------------------------attribute_click_handler starts here
attribute_click_handler(id,index,axis){
//---------------To handle dataset clicks
if(axis=='y'){
  console.log(id)
  this.togglePopup();
}
else{
  var arr=this.state.clickedA;
//---------------To remove attributes from array
  if(this.state.clickedA.includes(index)){
    arr = this.state.clickedA.filter(function(e) { return e !== index })
    console.log('if',id);
    this.classRemover(id,'textcolor');
  }
  else{
    this.classAdder(id,'textcolor')
    console.log('else',id);
    arr.push(index)
  }
  this.setState({clickedA:arr},()=>{
    // change Here to implement all attributes or selected attributes
    if(this.state.viewgrouptracker==2){
      this.view_group();
    }
    else{
      this.view_group2();
    }
  })
}
  }
//----------------------------------------------------- Class Adder
classAdder = (id,class_name)=>{
var element = document.getElementById(id);
//element.style.fill = 'blue';
element.classList.add(class_name);
}
//----------------------------------------------------- Class Remover
classRemover = (id,class_name)=>{
  var element = document.getElementById(id);
  element.classList.remove(class_name);
  }  
//-----------------------------------------------------ComponentDidmount
componentDidMount(){
  var unionedA=this.Unionmaker(this.state.mydata2);
  this.setState({unionmade:unionedA})
  //console.log(unionedA)
  var matrixdata=algorithms.matrixgen(unionedA,this.state.mydata2);
  this.setState({matrixdata:matrixdata})
}
componentDidUpdate(prevState,prevProp){
  return false;
}
/*
shouldComponentUpdate(nextProps, nextState){
  if(count>3){
    console.log(nextState);
    return false;
  }
  else{
    return true;
  }
}
*/
//----------------------------------------------------- togglePopup
togglePopup(){
  this.setState({
    showPopup: !this.state.showPopup
  });
}
render() {
  if(Object.keys(this.state.matrixdata).length>0){
  }
    return (
     <div className="container-fluid">
        <div className="row">
              
              <div className="col-3">
              <button onClick={this.view_group} className="btn  btn-outline-secondary">Group with all attributes</button>
              <button onClick={this.view_group2} className="btn  btn-outline-secondary"> Group with only clicked attributes</button>
              </div>
              
              <div className="matrix col-9">
              {
                  (Object.keys(this.state.matrixdata).length>0)?<HeatMap key={'key1'} gdatasets={[]} display='main' clickhandler={this.attribute_click_handler} datasets={this.state.matrixdata} commonA={this.state.unionmade} />:"NA"
              }
              {this.state.groups}
              </div>
              
        </div>      
      {// pop up window 
        this.state.showPopup ? 
          <Popup
            text='Close Me'
            closePopup={this.togglePopup.bind(this)}
          />
          : null
      }
    </div>
    );
  }
}
export default App;

