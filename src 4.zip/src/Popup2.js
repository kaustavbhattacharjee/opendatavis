import React, { Component } from 'react'
class Popup extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      popdata:{},
    }
this.jsonHandler2 = this.jsonHandler2.bind(this);
  }
  jsonHandler2(){
    const self=this;
    var url = "http://127.0.0.1:5000/json";
    var data = {datasets: this.props.data};
    fetch(url, {
      method: 'POST', 
      body: JSON.stringify(data),
      headers:{
        'Content-Type': 'application/json'
      }
    }).then(res => res.json())
    .then(response => {
      self.setState({popdata:response})
      console.log(response)
      return response;
    }).catch(error => console.error('Error:', error));
  }
  componentDidMount(){
  }
    render() {
      return (
        <div className='popup'>
          <div className='popup_inner'>
          <button className="btn btn-info" onClick={this.props.closePopup}>close</button>
          </div>
          <div className="popdiv">
            <p>{this.props.data}</p>
          </div>
        </div>
      );
    }
  }
  export default Popup;