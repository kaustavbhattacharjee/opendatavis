import React, { Component } from 'react'
class Popup extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      popdata:{},
    }
this.jsonHandler2 = this.jsonHandler2.bind(this);
  }
  jsonHandler2(){
    const self=this;
    var url = "http://127.0.0.1:5000/json";
    var myfilename=this.props.data+".csv"
    var data = {filename: myfilename};
    fetch(url, {
      method: 'POST', 
      body: JSON.stringify(data),
      headers:{
        'Content-Type': 'application/json'
      }
    }).then(res => res.json())
    .then(response => {
      self.setState({popdata:response})
      console.log(response)
      return response;
    }).catch(error => console.error('Error:', error));
  }
  componentDidMount(){
    console.log("Hello world")
    this.jsonHandler2()
  }
    render() {
      return (
        <div className='popup'>
          <div className='popup_inner'>
          <button className="btn btn-info" onClick={this.props.closePopup}>close</button>
          </div>
          <div className="popdiv">
            <p>{this.props.data}</p>
            <p>{"Number of rows: "+this.state.popdata.number_of_rows}</p>
            <p>{"Number of columns: "+this.state.popdata.number_of_columns}</p>
              {this.state.popdata.attributes}

          </div>
        </div>
      );
    }
  }
  export default Popup;